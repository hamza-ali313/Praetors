<?php
$page = 'Custom Web App Development | The Praetors';
$pageDesc = 'We provide custom web application development solutions for all 
business needs. With a focus on performance, our developers create feature-rich, responsive web apps!
';
include 'includes/header.php';
?>


<!-- banner sec start -->
<section class="banner_lp-2 services" id="home">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-md-5 col-sm-12 p-0">
                <div class="banner_content_left wow fadeInLeft">
                    <h2>
                        Custom Web Application Development Services
                    </h2>
                    <p>
                        Transform your vision into reality with The Praetors' specialized custom web application
                        development services. Our experienced developers thrive on the challenge of crafting innovative,
                        personally tailored digital solutions. Through collaborative design and iterative delivery, we
                        sculpt precisely what you envision - powerful platforms with streamlined workflows, intelligent
                        integrations and engaging interfaces. Built on a foundation of security, scalability and
                        performance, our custom solutions empower users while boosting key metrics for your business.
                    </p>
                    <ul>
                        <li>
                            <a href="javascript:;" class="btn1">LET’S BUILD YOUR SOFTWARE NOW
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-12 p-0">
                <!--<div class="banner_side_img ">-->
                <!--    <img class="lazyload" src="images/ban1.png" alt="badges">-->
                <!--    <img src="images/frame4.png" alt="" class='frame4'>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    <!--<img src="images/frame1.png" alt="" class='ban-bef'>-->
    <!--<img src="images/frame2.png" alt="" class='frame2'>-->
    <!--<img src="images/frame3.png" alt="" class='frame3'>-->
</section>
<!-- banner sec end-->


<!-- serv-sec2 start -->
<section class="serv-sec2">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-12 col-lg-6">
                <div>
                    <h4>
                        Partner with <span>Custom Web App Development</span> Company for Robust, Performance-Driven
                        Products!
                    </h4>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div>
                    <p>
                        Looking to take your web presence and digital offerings to the next level? Partner with The
                        Praetors, a leading design and development firm in the US for industry-leading web application
                        development services. With a deep understanding of programming best practices and technologies,
                        we craft robust, high-performing solutions perfectly tailored to your business needs. Through
                        rigorous testing and optimization, our developers ensure your app loads fast, works seamlessly
                        across devices and stands up to heavy usage.
                    </p>
                    <p>
                        You'll also gain a dedicated team providing long-term support - continuously innovating and
                        helping your online solutions and profile evolve as your company grows.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec2 end -->

<!-- serv-sec3 start -->
<section class="serv-sec3">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-12 col-lg-6">
                <div class='mb-5'>
                    <h4>
                        Explore Our Expert <span>Web Application Development</span> To Transform Data into Decisions
                        with
                        Insight-Yielding Interfaces
                    </h4>
                    <p>
                        Leverage The Praetors’ extensive web development expertise to transform data into strategic
                        business advantages. Our custom applications integrate seamlessly with your existing systems to
                        aggregate and analyze complex information flows. With finely-tuned interfaces built on
                        progressive web technologies, you gain insightful real-time dashboards and visualizations
                        crafted for your specific reporting and decision-making needs.
                    </p>
                    <p>
                        Whether you require automated forecasts, sales performance overviews or operational metrics, we
                        design personalized data-driven solutions that fuel smarter choices and maximize every
                        opportunity for growth.
                    </p>
                    <a href="javascript:;" class="btn1">Let’s Build Your App Now</a>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="serv-sec3-box">
                    <h6>Insightful Data Visualizations and Reporting</h6>
                    <p>
                        Our developers craft customized interfaces and dashboards that transform raw numbers into clear,
                        actionable visuals. Dynamic charts, scorecards and heat maps provide intuitive overviews to help
                        monitor KPIs, spot trends and pinpoint areas for improvement.
                    </p>
                </div>
                <div class="serv-sec3-box">
                    <h6>Real-Time Data Integration</h6>
                    <p>
                        We integrate seamlessly with your existing databases and systems to aggregate both internal and
                        external data streams into your custom application. This unified platform ensures you have
                        powerful real-time insights at your fingertips for informed, timely decisions.
                    </p>
                </div>
                <div class="serv-sec3-box">
                    <h6>Predictive Analytics Capabilities</h6>
                    <p>
                        Leveraging machine learning techniques, our apps process past performance patterns to generate
                        accurate automated forecasts of future outcomes. Sales projections, inventory needs and other
                        predictive insights give you strategic guidance to proactively shape business results.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec3 end -->

<!-- tech stack tabs start -->
<section class='tech-tabs-sec'>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-12">
                <div class="text-center">
                    <h4>
                        Innovative Web Application Development, Driven by Dynamic Tech Stacks
                    </h4>
                    <p>
                        We offer custom web apps powered by state-of-the-art technology.
                    </p>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-12 col-lg-12">
                <div class='tech-tabs'>
                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-IOS-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-IOS" type="button" role="tab" aria-controls="pills-IOS"
                                aria-selected="true">Frontend</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Android-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Android" type="button" role="tab" aria-controls="pills-Android"
                                aria-selected="false">Backend</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Cross-Platform-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Cross-Platform" type="button" role="tab"
                                aria-controls="pills-Cross-Platform" aria-selected="false">Mobile</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Prograssive-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Prograssive" type="button" role="tab"
                                aria-controls="pills-Prograssive" aria-selected="false">Database</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Frameworks-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Frameworks" type="button" role="tab"
                                aria-controls="pills-Frameworks" aria-selected="false">Frameworks</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Cloud-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Cloud" type="button" role="tab" aria-controls="pills-Cloud"
                                aria-selected="false">Cloud</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-DevOps-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-DevOps" type="button" role="tab" aria-controls="pills-DevOps"
                                aria-selected="false">DevOps</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Ecommerce-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Ecommerce" type="button" role="tab"
                                aria-controls="pills-Ecommerce" aria-selected="false">Ecommerce</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-CMS-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-CMS" type="button" role="tab" aria-controls="pills-CMS"
                                aria-selected="false">CMS</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Platforms-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Platforms" type="button" role="tab"
                                aria-controls="pills-Platforms" aria-selected="false">Platforms</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-IOS" role="tabpanel"
                            aria-labelledby="pills-IOS-tab">
                            <ul>
                                <li>
                                    <img src="images/front1.png" alt="">
                                    <h2>TezJS</h2>
                                </li>
                                <li>
                                    <img src="images/front2.png" alt="">
                                    <h2>AngularJS</h2>
                                </li>
                                <li>
                                    <img src="images/front3.png" alt="">
                                    <h2>ReactJS</h2>
                                </li>
                                <li>
                                    <img src="images/front4.png" alt="">
                                    <h2>Vue.js</h2>
                                </li>
                                <li>
                                    <img src="images/front5.png" alt="">
                                    <h2>JavaScript</h2>
                                </li>
                                <li>
                                    <img src="images/front6.png" alt="">
                                    <h2>CSS3</h2>
                                </li>
                                <li>
                                    <img src="images/front7.png" alt="">
                                    <h2>HTML5</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Android" role="tabpanel"
                            aria-labelledby="pills-Android-tab">
                            <ul>
                                <li>
                                    <img src="images/back1.png" alt="">
                                    <h2>.NET</h2>
                                </li>
                                <li>
                                    <img src="images/back2.png" alt="">
                                    <h2>Node.js</h2>
                                </li>
                                <li>
                                    <img src="images/back3.png" alt="">
                                    <h2>PHP</h2>
                                </li>
                                <li>
                                    <img src="images/front4.png" alt="">
                                    <h2>Java</h2>
                                </li>
                                <li>
                                    <img src="images/back5.png" alt="">
                                    <h2>Python</h2>
                                </li>
                                <li>
                                    <img src="images/back6.png" alt="">
                                    <h2>Express</h2>
                                </li>
                                <li>
                                    <img src="images/back7.png" alt="">
                                    <h2>Fastify</h2>
                                </li>
                                <li>
                                    <img src="images/back8.png" alt="">
                                    <h2>Meteor.js</h2>
                                </li>
                                <li>
                                    <img src="images/back9.png" alt="">
                                    <h2>Nest.js</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Cross-Platform" role="tabpanel"
                            aria-labelledby="pills-Cross-Platform-tab">
                            <ul>
                                <li>
                                    <img src="images/mob1.png" alt="">
                                    <h2>Android</h2>
                                </li>
                                <li>
                                    <img src="images/mob2.png" alt="">
                                    <h2>iOS</h2>
                                </li>
                                <li>
                                    <img src="images/mob3.png" alt="">
                                    <h2>Swift</h2>
                                </li>
                                <li>
                                    <img src="images/mob4.png" alt="">
                                    <h2>Flutter</h2>
                                </li>
                                <li>
                                    <img src="images/mob5.png" alt="">
                                    <h2>Ionic</h2>
                                </li>
                                <li>
                                    <img src="images/front3.png" alt="">
                                    <h2>React Native</h2>
                                </li>
                                <li>
                                    <img src="images/mob6.png" alt="">
                                    <h2>Xamarin</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Prograssive" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/database1.png" alt="">
                                    <h2>SQL Server</h2>
                                </li>
                                <li>
                                    <img src="images/database2.png" alt="">
                                    <h2>MySQL</h2>
                                </li>
                                <li>
                                    <img src="images/database3.png" alt="">
                                    <h2>PostgreSQL</h2>
                                </li>
                                <li>
                                    <img src="images/database4.png" alt="">
                                    <h2>MongoDB</h2>
                                </li>
                                <li>
                                    <img src="images/database5.png" alt="">
                                    <h2>Oracle </h2>
                                </li>
                                <li>
                                    <img src="images/database6.png" alt="">
                                    <h2>DynamoDB</h2>
                                </li>
                                <li>
                                    <img src="images/database7.png" alt="">
                                    <h2>SQLite</h2>
                                </li>
                                <li>
                                    <img src="images/database8.png" alt="">
                                    <h2>Firebase</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Frameworks" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/fra1.png" alt="">
                                    <h2>Rxweb.io</h2>
                                </li>
                                <li>
                                    <img src="images/fra2.png" alt="">
                                    <h2>Laravel</h2>
                                </li>
                                <li>
                                    <img src="images/fra3.png" alt="">
                                    <h2>CodeIgniter</h2>
                                </li>
                                <li>
                                    <img src="images/fra4.png" alt="">
                                    <h2>MEAN</h2>
                                </li>
                                <li>
                                    <img src="images/fra5.png" alt="">
                                    <h2>CakePHP</h2>
                                </li>
                                <li>
                                    <img src="images/fra6.png" alt="">
                                    <h2>Django</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Cloud" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/cloud1.png" alt="">
                                    <h2>AWS</h2>
                                </li>
                                <li>
                                    <img src="images/cloud2.png" alt="">
                                    <h2>Google Cloud</h2>
                                </li>
                                <li>
                                    <img src="images/cloud3.png" alt="">
                                    <h2>Azure</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-DevOps" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/jen1.png" alt="">
                                    <h2>Jenkins</h2>
                                </li>
                                <li>
                                    <img src="images/cloud3.png" alt="">
                                    <h2>Azure DevOps</h2>
                                </li>
                                <li>
                                    <img src="images/jen2.png" alt="">
                                    <h2>Docker</h2>
                                </li>
                                <li>
                                    <img src="images/jen3.png" alt="">
                                    <h2>Kubernetes</h2>
                                </li>
                                <li>
                                    <img src="images/jen4.png" alt="">
                                    <h2>Selenium</h2>
                                </li>
                                <li>
                                    <img src="images/jen5.png" alt="">
                                    <h2>Gradle</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Ecommerce" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/ecom1.png" alt="">
                                    <h2>WooCommerce</h2>
                                </li>
                                <li>
                                    <img src="images/ecom2.png" alt="">
                                    <h2>Magento</h2>
                                </li>
                                <li>
                                    <img src="images/ecom3.png" alt="">
                                    <h2>Shopify</h2>
                                </li>
                                <li>
                                    <img src="images/ecom4.png" alt="">
                                    <h2>Kentico</h2>
                                </li>
                                <li>
                                    <img src="images/ecom5.png" alt="">
                                    <h2>NopCommerce</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-CMS" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/cms1.png" alt="">
                                    <h2>WordPress</h2>
                                </li>
                                <li>
                                    <img src="images/cms2.png" alt="">
                                    <h2>Joomla</h2>
                                </li>
                                <li>
                                    <img src="images/ecom4.png" alt="">
                                    <h2>Kentico</h2>
                                </li>
                                <li>
                                    <img src="images/cms3.png" alt="">
                                    <h2>DotNetNuke</h2>
                                </li>
                                <li>
                                    <img src="images/cms4.png" alt="">
                                    <h2>Sitefinity</h2>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane fade " id="pills-Platforms" role="tabpanel"
                            aria-labelledby="pills-Prograssive-tab">
                            <ul>
                                <li>
                                    <img src="images/plate1.png" alt="">
                                    <h2>MS Dynamics CRM</h2>
                                </li>
                                <li>
                                    <img src="images/plate2.png" alt="">
                                    <h2>Zoho</h2>
                                </li>
                                <li>
                                    <img src="images/plate3.png" alt="">
                                    <h2>Power BI</h2>
                                </li>
                                <li>
                                    <img src="images/plate4.png" alt="">
                                    <h2>Salesforce </h2>
                                </li>
                                <li>
                                    <img src="images/plate5.png" alt="">
                                    <h2>Servicenow </h2>
                                </li>
                                <li>
                                    <img src="images/plate6.png" alt="">
                                    <h2>Tableau</h2>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- tech stack tabs end -->

<!-- brands-sec start-->
<section class="brands-sec client location">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div>
                    <h2 class="wow fadeInDown">Trusted by Global Enterprises</h2>
                    <div class="clients-slider wow fadeInLeft">
                        <div>
                            <img src="images/our-clients/client-1.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-2.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-3.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-4.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-5.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-6.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-7.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-8.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-9.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-10.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-11.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-12.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-13.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-14.png" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-15.jpg" alt="">
                        </div>
                        <div>
                            <img src="images/our-clients/client-16.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- brands-sec end-->


<!-- section portfolio start -->
<section class="port-sec1">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div>
                    <h3>portfolio</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section portfolio end -->

<!-- section portfolio start -->
<section class="port-sec2">
    <div class="container-fluid px-0">
        <div class="row">
            <div class="col-12 col-lg-6 px-0">
                <div class="port-sec2-left">
                    <h3>portfolio</h3>
                </div>
            </div>
            <div class="col-12 col-lg-6 px-0">
                <div class="port-sec2-right">
                    <h3>portfolio</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section portfolio end -->



<!-- serv-sec4 start -->
<section class="serv-sec4">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-12 col-lg-4">
                <div class='mb-5'>
                    <h4>
                        Our Seamless <span>Web Application Development</span> Services Process
                    </h4>
                    <p>
                        Our seamless development process starts with thorough discovery and analysis to understand your
                        unique needs and goals. Our designers then craft optimized solutions through interactive
                        prototyping and testing. Solid coding practices ensure robust, scalable products delivered
                        through an iterative approach. On-time, on-budget delivery is complemented by ongoing support,
                        enabling your app to continually meet evolving business demands.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-8">
                <div class="serv-sec">
                    <div class="row">
                        <div class="col-12 col-lg-4">
                            <div class="serv-box wow fadeInLeft">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>
                                        Discovery
                                    </h2>
                                    <p>
                                        We begin by understanding your needs and goals and gathering essential
                                        information to lay the foundation for our collaboration.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="serv-box wow fadeInRight">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>Planning
                                    </h2>
                                    <p>
                                        With a clear understanding, we develop a detailed plan outlining the scope,
                                        timeline, and resources required for the project.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="serv-box wow fadeInDown">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>Design
                                    </h2>
                                    <p>
                                        Our team creates intuitive, user-friendly designs, ensuring the app aligns
                                        seamlessly with your vision and objectives.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="serv-box wow fadeInUp">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>Development
                                    </h2>
                                    <p>
                                        Our skilled team of custom developers brings the designs to life, meticulously
                                        coding and building the app according to the outlined specifications.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="serv-box wow fadeInRight">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>Testing
                                    </h2>
                                    <p>
                                        Rigorous testing procedures are conducted to identify and resolve any issues,
                                        ensuring the apps meet high quality and functionality standards.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                            <div class="serv-box wow fadeInRight">
                                <div class="conte">
                                    <img src="images/mat1.png" alt="">
                                    <h2>Launch
                                    </h2>
                                    <p>
                                        Once thoroughly tested and approved, we deploy the application, providing
                                        comprehensive support and guidance to ensure a smooth transition and optimal
                                        performance.
                                    </p>
                                </div>
                                <div class="btn-sec">
                                    <a href="javascript:;">Get Started <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec4 end -->


<!-- heaading sec start -->
<section class="heading-sec">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-12">
                <div class="wow fadeInLeft text-center">
                    <h2>Diversified Industry Experience
                    </h2>
                    <p>
                        We’ve refined our custom app development expertise across diverse industries, including
                        healthcare, finance, retail, media, hospitality, and more. Each has unique needs, which we
                        address through tailored solutions focused on user experience and robust functionality. Review
                        client examples from your specific vertical to learn how our custom mobile apps solve problems
                        and create value. Let our experience work for you!
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- heaading sec end -->

<!-- industry diversify start -->
<section class="indus-diver">
    <div class="container">
        <div class="row">
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInLeft indus-diver-box">
                    <img src="images/cate7.png" alt="">
                    <h6>Maps & Navigation</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInUp indus-diver-box">
                    <img src="images/cate6.png" alt="">
                    <h6>Healthcare</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInDown indus-diver-box">
                    <img src="images/cate5.png" alt="">
                    <h6>Food & Restaurant</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInRight indus-diver-box">
                    <img src="images/cate3.png" alt="">
                    <h6>Education & Academics</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInLeft indus-diver-box">
                    <img src="images/cate10.png" alt="">
                    <h6>On Demand Services</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInUp indus-diver-box">
                    <img src="images/cate9.png" alt="">
                    <h6>Business & Finance</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInDown indus-diver-box">
                    <img src="images/cate12.png" alt="">
                    <h6>Logistics</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInRight indus-diver-box">
                    <img src="images/cate1.png" alt="">
                    <h6>Travel & Hotel</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInLeft indus-diver-box">
                    <img src="images/cate2.png" alt="">
                    <h6>Ecommerce Retail B2B</h6>
                </div class="wow fadeInLeft ">
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInUp indus-diver-box">
                    <img src="images/cate11.png" alt="">
                    <h6>Social Networking</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInDown indus-diver-box">
                    <img src="images/cate4.png" alt="">
                    <h6>Entertainment</h6>
                </div>
            </div>
            <div class="col-12 col-xl-3 col-lg-4 col-md-4 col-sm-6">
                <div class="wow fadeInRight indus-diver-box">
                    <img src="images/cate8.png" alt="">
                    <h6>Event & Bookings</h6>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- industry diversify end -->

<!-- counter sec start -->
<section class="serv-counter-sec">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="count wow fadeInLeft">
                    <h1><span data-target="2">0</span>+</h1>
                    <p>Decades of Experience</p>
                </div>
            </div>
            <div class="col-12 col-lg-4 ">
                <div class="count wow fadeInUp">
                    <h1><span data-target="137">0</span>k+</h1>
                    <p>Clients Globally</p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="count wow fadeInUp">
                    <h1><span data-target="350">0</span>k+</h1>
                    <p>Digital Products Delivered</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- counter sec end -->

<!-- serv-sec5 start -->
<section class="serv-sec5">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-12 col-lg-6">
                <div class=''>
                    <h4>
                        Explore Our Game-Changing <span>Web Application Development</span> Services
                    </h4>
                    <p class="mt-5">
                        Are you ready to substantially boost business results with a tailored web application? Explore
                        our premium development services. Whether you require an e-commerce solution, HR portal or
                        custom software, our experts will seamlessly transform your concepts into polished,
                        top-performing digital products through dedicated agile methodologies.
                    </p>
                    <p class="mt-3">
                        Contact us today to discuss how we can help propel your organization to the next level through
                        advanced, securely-built web solutions.
                    </p>
                    <a href="" class='btn3'>Let’s Build Your Mobile App</a>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="serv-sec5-right">
                    <h6>Full Stack Development </h6>
                    <p>
                        Our expert full stack developers are equipped to design, develop and deploy complete web
                        application solutions from front end to back end. They leverage the right tools and technologies
                        to craft systems with optimized performance, scalability, functionality and intuitive UX. You
                        gain a single source for fully-integrated, seamlessly working apps.
                    </p>
                    <h6>API Development & Integration </h6>
                    <p>
                        We expertly design and build custom, scalable RESTful APIs to enable efficient data exchange
                        between your applications and systems. Whether migrating a legacy system or developing a new
                        one, our rock-solid, standardized APIs facilitate fast and simple integration. API-first
                        solutions connectivity is seamless.
                    </p>
                    <h6>Mobile-Responsive Designs </h6>
                    <p>
                        All design aspects automatically reformat content and interface elements to suit any device or
                        orientation. Users enjoy a native app-like experience on phones and tablets. Our responsive
                        frameworks make content perfectly readable on varied screens through fluid, grid-based layouts
                        optimized for touch.
                    </p>
                    <h6>DevOps & CI/CD </h6>
                    <p>
                        Our DevOps professionals implement infrastructure automation, version control, testing, security
                        and monitoring tools to support continuous delivery pipelines. Automated build-test-deploy
                        processes get updates to users rapidly while maintaining quality and stability. Developers stay
                        focused and productive.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec5 end -->

<!-- serv-sec6 start -->
<section class="serv-sec6">
    <div class="container">
        <div class="row align-items-start">
            <div class="col-12 col-lg-6">
                <div>
                    <h4>
                        Ultimate <span>Web App Development</span> Solutions Specific For Every Industry
                    </h4>
                    <p class="mt-5">
                        Whether you operate in healthcare, finance, retail, government or another sector, our expert
                        team provides ultimate custom web app development solutions tailored specifically for your
                        industry's unique needs and regulatory landscape. Leveraging deep experience building solutions
                        for various verticals, we craft secure, fully-compliant digital tools optimized for your
                        workflows and business goals.
                    </p>
                    <p class="mt-3">
                        Here are the sectors we cater to:
                    </p>
                    <a href="" class='btn3'>Let’s Build Your Mobile App</a>
                </div>
            </div>
            <div class="col-12 col-lg-6 position-relative">
                <div class="fea">
                    <h4>Retail</h4>
                    <h4>E-Commerce</h4>
                    <h4>Insurance</h4>
                    <h4>FinTech</h4>
                    <h4>Entertainment</h4>
                    <h4>Health & Fitness</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec6 end -->

<!-- serv-sec7 start -->
<section class="serv-sec7">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <h4 class='text-center'>
                    <span>Our Mission -</span> Empowering Your Journey with Innovation & Integrity
                </h4>
            </div>
        </div>
        <div class="row align-items-start mt-5">
            <div class="col-12 col-lg-6">
                <div>
                    <p class="mt-5">
                        At our core, our mission is to empower businesses with transformative digital solutions that
                        drive growth and innovation. We are dedicated to leveraging our expertise and creativity to
                        craft bespoke digital products that meet the unique needs and challenges of each client.
                    </p>
                    <p class="mt-3">
                        Our commitment to excellence guides every aspect of our work, from initial concept to final
                        delivery. We prioritize transparency, communication, and collaboration to ensure that our
                        clients are always informed and involved throughout the web application development process. By
                        fostering strong partnerships built on trust and reliability, we aim to become the go-to digital
                        partner for businesses seeking to thrive in today’s competitive landscape.
                    </p>
                    <p class="mt-3">
                        Our mission is not just to meet expectations, but to exceed them, delivering tangible results
                        and measurable impact for our clients. With a focus on continuous improvement and adaptation to
                        emerging technologies, we strive to stay at the forefront of the industry, driving innovation
                        and pushing boundaries to help our clients succeed in their digital endeavors.
                    </p>
                    <a href="" class='btn3'>Let’s Discuss Your Project</a>
                </div>
            </div>
            <div class="col-12 col-lg-6 position-relative">
                <div class="">
                    <img src="images/choos2.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec7 end -->

<!-- serv-sec7 start -->
<section class="serv-sec7">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <h4 class='text-center'>
                    Unlock the Power of Robust <span>Web Application Development</span> with The Praetors
                </h4>
            </div>
        </div>
        <div class="row align-items-center mt-5">
            <div class="col-12 col-lg-6 position-relative">
                <div class="">
                    <img src="images/choos2.png" alt="">
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div>
                    <p class="mt-5">
                        When you partner with The Praetors, a leading and reliable web application development company
                        in the US, you’re selecting a seasoned team of experts poised to transform your concepts into
                        successful applications.
                    </p>
                    <p class="mt-3">
                        We commence by attentively listening to your requirements, ensuring a thorough comprehension of
                        your aspirations.
                    </p>
                    <p class="mt-3">
                        Subsequently, our adept developers utilize their technical prowess to craft applications that
                        not only function seamlessly but also delight end users.
                    </p>
                    <p class="mt-3">
                        Our commitment extends beyond development; we pledge ongoing support and updates to maintain the
                        excellence of your application, allowing you to concentrate on business growth and customer
                        satisfaction.
                    </p>
                    <p class="mt-3">
                        <span>Quality-First Approach
                        </span>We’re all about delivering top-notch stuff, making sure it's spot-on and totally
                        reliable, so you're always happy with what you get.
                    </p>
                    <p class="mt-3">
                        <span>Robust Development</span> When we build a custom Android app, we make sure it’s brilliant
                        in every way and functions fully, handling whatever you need it to do. That’s how we roll!
                    </p>
                    <p class="mt-3">
                        <span>Latest Tech Stack
                        </span> We’re all about using the coolest, newest tech to make awesome custom apps that's ahead
                        of the game and helps your business grow.
                    </p>
                    <p class="mt-3">
                        <span>Complete Transparency
                        </span>We’re open books here, keeping you in the loop every step of the way so you know exactly
                        what's happening with your custom progressive web app development project. No secrets here!
                    </p>
                    <a href="" class='btn3'>Let’s Discuss Your Project</a>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- serv-sec7 end -->

<!-- serv-sec8 start -->
<section class="serv-sec3 serv-sec8">
    <div class="container">
        <div class="row align-items-center my-5">
            <div class="col-12 col-lg-6">
                <div>
                    <h4>
                        Why Opt For <span>Custom Web App Development</span> For Your Business?
                    </h4>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div>
                    <p>
                        There are numerous reasons to pursue a strategic investment in custom web application
                        development. A solution purpose-built around your unique requirements will optimize key
                        functions to drive efficiencies. Integration of proprietary data sources enables actionable
                        insight. Additionally, customizing the user experience strengthens your brand and relationships.
                    </p>
                    <p>
                        Our process focuses on goals like increased revenue, reduced costs, and sustained competitive
                        differentiation. Overall, a tailored digital platform can substantially elevate organizational
                        performance.
                    </p>
                </div>
            </div>
        </div>
        <div class="row align-items-start">
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Increased Operational Efficiency </h6>
                    <p>
                        A tailored solution streamlines complex workflows to save time and resources through automation
                        and integration.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Enhanced Customer Experience</h6>
                    <p>
                        Customizing interactions based on research builds loyalty by satisfying precise needs through an
                        intuitive, consistent experience.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Actionable Business Insights </h6>
                    <p>
                        Integrating diverse internal and external data sources unleashes customized analytics to reveal
                        patterns that guide strategic decisions.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Stronger Brand Identity </h6>
                    <p>
                        Incorporating your unique messaging, look and feel establishes a consistent digital presence
                        that deepens customer relationships.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Future Growth Capabilities</h6>
                    <p>
                        Innovative features keep your app aligned with evolving needs while its flexibility supports
                        business transformations.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="serv-sec3-box text-center">
                    <h6>Competitive Advantage </h6>
                    <p>
                        A proprietary solution delivers invaluable functionality that competitors cannot easily
                        replicate, keeping your organization ahead of the curve.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec8 end -->

<!-- serv-sec9 start -->
<section class="serv-sec9">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10 col-md-12 col-sm-12">
                <div class='text-center'>
                    <h4>
                        Perks of Working with an Expert <span>Web App Development</span> Company
                    </h4>
                    <p class='mt-2'>
                        Partnering with The Praetors ensures a seamless journey towards digital transformation through
                        web application development. We carefully handle every aspect to deliver a superior experience,
                        allowing you to effortlessly focus on your business growth.
                    </p>
                </div>
            </div>
        </div>
        <div class="row align-items-start mt-5">
            <div class="col-12 col-lg-3 col-md-6 col-sm-6 ">
                <div class="serv-sec9-box">
                    <h6>Future-Ready Products
                    </h6>
                    <p>
                        We’re all about staying ahead of the game, crafting innovative solutions that'll tackle
                        tomorrow’s challenges head-on.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 col-sm-6">
                <div class="serv-sec9-box">
                    <h6>Dedicated Team </h6>
                    <p>
                        Count on us to bring your ideas to life! Our web app developers
                        are dedicated, skilled, and ready to
                        make your vision a reality.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 col-sm-6">
                <div class="serv-sec9-box">
                    <h6>Customer Experience</h6>
                    <p>
                        We’re here to make your experience seamless and personalized, tailored just for you and your
                        success.
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-3 col-md-6 col-sm-6">
                <div class="serv-sec9-box">
                    <h6>Satisfaction Guarantee</h6>
                    <p>
                        Your satisfaction is our top priority. We're committed to making sure you're thrilled with the
                        results.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- serv-sec9 end -->

<!-- faq sec start -->
<section class="faq-sec">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-12 col-lg-9 col-sm-12 d-inline-block">
                <div class='faqheading'>
                    <h4>Custom Web Application Development Services: FAQs </h4>
                    <span>FAQs</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class='faq-box'>
                    <div class="faq-accordian-sec">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is custom web application development?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Custom web application development involves creating tailored software
                                            solutions specifically designed to meet the unique needs and requirements of
                                            a business or organization. These applications are built from scratch to
                                            address specific challenges and goals.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Why choose custom web application development over off-the-shelf solutions?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Custom web applications offer unparalleled flexibility, scalability, and
                                            customization compared to off-the-shelf solutions. They can be tailored
                                            precisely to match your business processes, integrate seamlessly with
                                            existing systems, and provide a competitive edge.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take to develop a custom web application?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            The development timeline for a custom web application varies depending on
                                            the complexity of the project, features required, and client specifications.
                                            On average, it can take anywhere from a few weeks to several months to
                                            complete the development process.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFour" aria-expanded="false"
                                        aria-controls="collapseFour">
                                        4. What technologies are used in custom web application development?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Custom web applications can be built using a variety of technologies,
                                            including programming languages such as JavaScript, Python, Ruby on Rails,
                                            and frameworks like React, Angular, and Vue.js. The choice of technology
                                            stack depends on project requirements and developer expertise.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseFive" aria-expanded="false"
                                        aria-controls="collapseFive">
                                        5. How much does custom web application development cost?
                                    </button>
                                </h2>
                                <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            The cost of custom web application development services depends on factors
                                            such as project scope, complexity, features, and development time. It is
                                            usually calculated based on hourly rates for development services, with
                                            additional costs for design, testing, and maintenance.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingFour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                        6. Do you provide ongoing support and maintenance for custom web applications?
                                    </button>
                                </h2>
                                <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <p>
                                            Yes, we offer comprehensive support and maintenance services for web
                                            applications to ensure they remain secure, up-to-date, and optimized for
                                            performance. Our team provides regular updates, bug fixes, and technical
                                            assistance to keep your web application running smoothly.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- faq sec end -->

<!-- blogs sec start -->
<section class="blogs-sec">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div class='text-center'>
                    <h4>
                        Our Latest Blog Posts
                    </h4>
                </div>
            </div>
        </div>
        <div class="row align-items-start mt-5">
            <div class="col-12 col-lg-4">
                <div class="blog-box">
                    <img src="images/blog5.png" alt="blog5">
                    <h6>
                        How to Develop an Android
                        App: A Complete Guide
                    </h6>
                    <p>
                        There are around 2.69 million apps for
                        Android smartphones. Almost everyone
                        understands Android apps, and many are
                        ready to launch their own. But...
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="blog-box">
                    <img src="images/blog5.png" alt="blog5">
                    <h6>
                        Android App Development
                        Cost in 2024: A Brief Guide
                    </h6>
                    <p>
                        Android app is the real gateway for the digital transformation of any business scaling up the
                        approach to connect with the maximum users. According...
                    </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="blog-box">
                    <img src="images/blog5.png" alt="blog5">
                    <h6>
                        Why a Custom Android App Is
                        Better than a Ready-Made
                        Solution
                    </h6>
                    <p>
                        In the last couple of years, Android has become the first option for a lot of startups when they
                        launch their app
                    </p>
                </div>
            </div>
            <div class='text-center mt-5'>
                <a href="" class="btn3">view all</a>
            </div>
        </div>
    </div>
</section>
<!-- blogs sec end -->


<!-- from praetor pg start -->
<section class="work_together_sec" id="contact">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-sm-12">
                <div class="services_wrp_inner text-center">
                    <h4>Let's work together</h4>
                    <h2>We’re The Mobile Apps Development Company You Want!</h2>
                    <p>
                        Ready to transform your mobile presence? We’re here! Get in touch to explore how we can help you
                        better engage customers, gain a competitive edge, and unlock growth. Let's turn your app vision
                        into reality!
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5 justify-content-center">
            <div class="col-12 col-lg-8 col-md-8 col-sm-12">
                <div class="bottom_form-lp-2">
                    <form action="javascript:;" class="form-get-quote">
                        <div class="name_wrap">
                            <input type="text" placeholder="Name" name="" required>
                            <input type="email" placeholder="Email" name="" required>
                        </div>
                        <input type="tel" placeholder="Phone Number" required minlength="10" maxlength="11" name="">
                        <textarea name="" placeholder="Enter Your Message"></textarea>
                        <input type="text" name="" hidden value=119.73.97.61>
                        <input type="text" name="" hidden value=2024/02/23>
                        <div class="icon_btn">
                            <button type="submit">submit <i class="fas fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- <footer class="lp-2_footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-12">
                <div class="footer-logo">
                    <a href=""><img class="lazyload" src="images/foot-logo.png"></a>
                </div>
                <div class="lp-2_footer">
                    <h2>Our Contact</h2>
                    <ul>
                        <li><i class="fa-solid fa-phone"></i></li>
                        <li> <a href="tel:(855) 772-6090"> (855) 772-6090</a></li>
                    </ul>
                    <ul>
                        <li><i class="fa-solid fa-envelope"></i></li>
                        <li><a href="mailto:info@thepraetors.com" class="__cf_email__"> info@thepraetors.com</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2 col-sm-12">
                <div class="lp-2footer_inner idher-udhur">
                    <h3>Quick Links</h3>
                </div>
                <div class="footer_box_gl">
                    <ul>

                        <li><a href="javascript:void(0);">Services</a></li>
                        <li><a href="javascript:void(0);">Our Work</a></li>
                        <li><a href="javascript:void(0);">Clients</a></li>
                        <li><a href="javascript:void(0);">Why
                                Choose Us</a></li>
                        <li><a href="javascript:void(0);">Testimonials
                            </a></li>
                        <li><a href="javascript:void(0);">Contact</a></li>
                        <li><a href="javascript:;" target="_blank">Terms Of Use</a></li>
                        <li><a href="javascript:;" target="_blank">Privacy
                                Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-7 col-sm-12">
                <div class="lp-2footer_inner footer_link_margin">
                    <h3>Our Offices</h3>
                </div>
                <div class="row new_footer_inner">
                    <div class="col-md-6 col-sm-12">
                        <div class="footer_box_gl">
                            <h4>California - Costa Mesa</h4>
                            <p>555 Anton Blvd, #150 Costa Mesa, CA 92626</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="footer_box_gl">
                            <h4>New York - New York</h4>
                            <p>287 Park Avenue South, New York, NY 10010</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<section class="footer_bottom_wrp">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <p>© 2023 The Praetors. All Rights Reserved.</p>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="lp-2footer_inner">
                    <ul>
                        <li><a href="javascript:;" target="_blank"><i class="fa-brands fa-facebook"></i></a></li>

                        <li><a href="javascript:;" target="_blank"><i class="fa-brands fa-linkedin"></i></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="dis" style="background:#000;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="global_disclamer text-center p-1">
                    <h2 style="color: #fff; font-weight: 400; font-size: 20px; margin: 0; line-height: 40px;">
                        Disclaimer:</h2>
                    <p style="color:#fff; font-weight: 400; font-size: 14px; line-height: 26px;">
                        All company logos and trademarks appearing on our website
                        are
                        the property of their respective owners.
                        We are not affiliated, associated, endorsed by, or in any
                        way
                        officially connected with these companies
                        or their trademarks. The use of these logos and trademarks
                        does not imply any endorsement, affiliation,
                        or relationship between us and the respective companies. We
                        solely use these logos and trademarks for
                        identification purposes only. All information and content
                        provided on our website is for informational
                        purposes only and should not be construed as professional
                        advice. We do not guarantee the accuracy or
                        completeness of any information provided on our website. We
                        are not responsible for any errors or omissions,
                        or for the results obtained from the use of this
                        information.
                        Any reliance you place on such information
                        is strictly at your own risk.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!-- from praetor pg end -->



<?php
include 'includes/footer2.php';
$page = 'home';
?>